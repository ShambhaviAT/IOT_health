from __future__ import print_function
from MCP3008 import MCP3008
import RPi.GPIO as GPIO

import time
lop = 19
lom = 26

f = open("b.b","w")

GPIO.setmode(GPIO.BCM)
GPIO.setup(lop, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(lom, GPIO.IN, pull_up_down=GPIO.PUD_UP)

adc = MCP3008(0, 0)
n = 20
i = 0
print( GPIO.input(lop), GPIO.input(lom) )
print("A B")
while i<n:
    print("%d %d" % (i,adc.read(0)), file=f)
    time.sleep(0.01)
    i+=1
