#!/usr/bin/python
import RPi.GPIO as GPIO

lop = 19
lom = 26

GPIO.setmode(GPIO.BCM)
GPIO.setup(lop, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(lom, GPIO.IN, pull_up_down=GPIO.PUD_UP)

lop_val = GPIO.input(lop)
lom_val = GPIO.input(lom)

def isConnected(lopv,lomv):
    if lopv == 1 and lomv == 1:
        print(0)
    else:
        print(1)

#print(lop_val, lom_val)
isConnected(lop_val, lom_val)
