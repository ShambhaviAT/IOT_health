#!/usr/bin/python

from __future__ import print_function
import cgi
import cgitb
from MCP3008 import MCP3008
import RPi.GPIO as GPIO
import time
import os

cgitb.enable()

print("Content-type: text/html\n\n")
print("<h1>ECG SCAN</h1>")

lop = 19
lom = 26

GPIO.setmode(GPIO.BCM)
GPIO.setup(lop, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(lom, GPIO.IN, pull_up_down=GPIO.PUD_UP)

lop_val = GPIO.input(lop)
lom_val = GPIO.input(lom)

def isConnected(lopv,lomv):
    if lopv == 0 and lomv == 0:
        return 1 #ok
    else:
        return 0 #not ok

#print(lop_val, lom_val)

if isConnected(lop_val, lom_val)==1:
    print("<h2>Electrodes connected <br>reading data....</h2><br>")
    adc = MCP3008(0, 0)
    f = open("ecg.dat","w")
    n = 1500
    i = 0
    while i<n:
        print( "%d" % adc.read(0), file=f )
        time.sleep(0.005)
        i+=1
    print("<h2>reading done</h2><br>")
    f.close()

    cmd = '/usr/bin/sudo /usr/bin/scp /usr/lib/cgi-bin/ecg.dat sana@192.168.43.113:/home/sana'  
    ret = os.system(cmd)
    if ret == 0:
        print("file transfered<br>")
    else:
        print("error in transferring file..try again<br>")

else:
    print("<h2>Electrodes not connected</h2>")


