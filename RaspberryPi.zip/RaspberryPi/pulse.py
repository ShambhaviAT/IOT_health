#!/usr/bin/python

from __future__ import print_function
import cgi
import cgitb
from mcpp import mcpp
import RPi.GPIO as GPIO
import time
import os

cgitb.enable()

print("Content-type: text/html\n\n")
print("<h1>PULSE RATE MEASUREMENT</h1>")

"""lop = 19
lom = 26

GPIO.setmode(GPIO.BCM)
GPIO.setup(lop, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(lom, GPIO.IN, pull_up_down=GPIO.PUD_UP)

lop_val = GPIO.input(lop)
lom_val = GPIO.input(lom)"""

adc = mcpp(0, 0)
f = open("pulse.dat","w")
n = 10
i = 0
pulse=0
wrong=0
while i<n:
    #print( "%d" % adc.read(1) )
    cur_pulse = adc.read(1)

    if cur_pulse < 600 and cur_pulse > 400:
        pulse = pulse+cur_pulse
        i+=1
        #print(cur_pulse)
    else:
        #print('Connect Pulse Rate Sensor')
        f.close()
        time.sleep(1)
        f = open("pulse.dat","w")
        print("<h2>Place Finger on pulse sensor <br>Try Again....</h2><br>")
        wrong=1
        break;
    time.sleep(0.5)

if wrong == 0:
    pulse = pulse/(70)
    print(pulse, file=f)
    print("<h2>Pulse Rate = %d</h2>" %pulse);
#print("<h2>reading done</h2><br>")
f.close()

cmd = '/usr/bin/sudo /usr/bin/scp /usr/lib/cgi-bin/pulse.dat sana@192.168.43.113:/home/sana'
ret = os.system(cmd)
if ret == 0:
    #print("file transfered<br>")
    print(".")
else:
    print("error transferring Data to the server..try again<br>")
