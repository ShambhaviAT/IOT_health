<?php
//echo $_POST["uname"];
//echo $_POST["passwd"];
if($_POST["uname"] == 'BLDEAHMS' && $_POST["passwd"] == 'Password@3')
	header('Location:/home.html'); //echo "valid";
else
	header('Location:/index.html'); //echo "invalid"	
?>
