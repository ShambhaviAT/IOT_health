<?php
$t=time();
echo($t . "<br>");
echo "The time is " . date("d-m-Y-h-i-sa",$t);
echo exec('mv /home/sana/ecg.dat /home/sana/eeccgg.datt');
?> 
